
# Week 2 – Retail Sales Analytics

## Project Overview
This project analyzes retail sales data to understand sales performance,
product demand, customer behavior, and business trends.

## Tools & Technologies
- Python
- Pandas
- NumPy
- Matplotlib
- Microsoft Excel
- Jupyter Notebook

## Dataset Summary
- Total Records: 1,997
- Total Columns: 20
- Unique Customers: 623
- Date Range: 01 Jan 2025 – 31 Aug 2026

## Key Performance Indicators
- Total Orders: 1,997
- Total Units Sold: 4,505
- Gross Sales: ₹35,353,537.46
- Discount Amount: ₹3,581,621.36
- Net Sales: ₹31,771,916.10
- Average Order Value: ₹15,909.82

## Analysis Performed
- Data Cleaning
- Monthly Sales Analysis
- Product Analysis
- Category Analysis
- Regional Analysis
- City Analysis
- Customer Analysis
- Sales Channel Analysis
- Payment Mode Analysis
- Order Status Analysis
- Discount Analysis

## Key Findings
- Electronics was the highest-revenue category.
- West was the highest-performing region.
- Online sales were higher than offline sales.
- UPI was the most frequently used payment method.
- Smart Watch was the top product by quantity.
- 529 repeat customers and 94 one-time customers.

## Project Deliverables
- Raw Dataset
- Cleaned Dataset
- Python Notebook
- Excel Dashboard
- Charts and Visualizations
- Business Insights
- Final PDF Report

## Author
Gauri Arjun Gole
MCA (Pursuing) – IICMR, Pune
